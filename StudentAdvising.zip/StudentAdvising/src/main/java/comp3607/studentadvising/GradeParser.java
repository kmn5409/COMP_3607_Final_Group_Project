/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.util.HashMap;

/**
 *
 * @author njaco
 */
public class GradeParser extends FileParser{
    @Override
    Object addEntry(Object o, String[] record) {
        HashMap<String, Double> gradeMap = (HashMap<String, Double>) o;
        gradeMap.put(record[0], Double.parseDouble(record[1]));
        return gradeMap;
    }

    @Override
    Object getContainer() {
        return new HashMap<String, Double>();
    }
}
