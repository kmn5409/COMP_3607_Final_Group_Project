package comp3607.studentadvising;

import java.util.HashMap;

/**
 *GradeParse extends the FileParser template to implement the variable steps 
 * Creates a HashMap of grade-point pairs
 * @author njaco
 */
public class GradeParser extends FileParser{
    /**
     * Takes the records read from the file adds pair of values it contains to a HashMap and returns the HashMap
     * @param o
     * @param record
     * @return 
     */
    @Override
    Object addEntry(Object o, String[] record) {
        HashMap<String, Double> gradeMap = (HashMap<String, Double>) o;
        gradeMap.put(record[0], Double.parseDouble(record[1]));
        return gradeMap;
    }

    @Override
    Object getContainer() {
        return new HashMap<String, Double>();
    }
}
