package comp3607.studentadvising;

/**
 *
 * @author njaco
 */

import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

/**
 * 
 * Transcript class fetches the file and performs calculations for the GPA
 */
public class Transcript {
    private HashMap<Course, String> completedCourses;
    private CourseCatalog cc;
    private double GPA;
    private TranscriptParser tp;
    private GradeParser gp; 
    private HashMap<String, Double> gradeMap;
    
    /**
     * Constructor
     * @param filePath location of the transcript file
     */
    public Transcript(String filePath){
        File file = new File("src/main/java/comp3607/studentadvising/qualityPoints.txt");
        String absolutePath = file.getAbsolutePath();
        gp = new GradeParser();
        gradeMap = (HashMap<String, Double>) gp.parse(absolutePath);
        completedCourses = new HashMap<>();
        tp =  new TranscriptParser();
        completedCourses = (HashMap<Course, String>) tp.parse(filePath);
        calculateGPA();
//        System.out.println(this.GPA);
    }
    
    
    /**
     * Calculated the GPA based on completed courses and sets the GPA attribute
     * If the transcript file was badly formatted, it sets the GPA to -1 so code can be used to determine when an error message is to be displayed
     */
    private void calculateGPA(){
        int totalHours = 0;
        double totalPoints = 0;
        for (Map.Entry element : this.completedCourses.entrySet()){
            Course c = (Course)element.getKey();
            try{
                totalPoints += this.gradeMap.get((String)element.getValue()) * c.getCreditHours();
            }
            catch (Exception e) {
            this.completedCourses = null;
            this.GPA = -1;
            return;
        }
            totalHours += c.getCreditHours();   
        }
        this.GPA = totalPoints/totalHours;
    }
    
    public double getGPA(){
        return this.GPA;
    }
    /**
     * gets the failed courses by using a regular expression to find all courses with grades starting with F
     * @return failedCourses
     */
    public ArrayList<Course> getFailedCourses(){
        ArrayList<Course> failedCourses = new ArrayList<>();
        completedCourses.keySet().forEach(c -> {
            Pattern pattern = Pattern.compile("^F");
            Matcher matcher = pattern.matcher(completedCourses.get(c));
            if (matcher.find()) {
                failedCourses.add(c);
            }
        });
        return failedCourses;
    }
    
    /**
     * gets the completed courses by compiling the keys of the HashSet into an ArrayList
     * @return courses
     */
    public ArrayList<Course> getCompletedCourses(){
        if(this.completedCourses == null) return null;
        ArrayList<Course> courses = new ArrayList<>();
        this.completedCourses.entrySet().forEach(element -> {
            courses.add((Course)element.getKey());
        });
        return courses;
    }
    
}
