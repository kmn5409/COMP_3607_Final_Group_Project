package comp3607.studentadvising;

/**
 *
 * @author njaco
 */
import java.util.ArrayList;
import java.util.Objects;


/**
 *  Course class which contains attributes and methods necessary for modeling a that a student might take.
 * 
 */
public class Course {
    private String code;
    private String title;
    private String type;
    private int semesterOffered;
    private int creditHours;
    private int level;
    private String[] prerequisites;
    
    /**
     * Constructor initialize a Course with necessary attributes
     * @param code course code
     * @param title course title
     * @param creditHours the hours and how much the credit is worth
     * @param semesterOffered semester the course is available for
     * @param type core or elective course
     */
    public Course(String code, String title, int creditHours, int semesterOffered, String type){
        this.code = code;
        this.title = title;
        this.type = type;
        this.semesterOffered = semesterOffered;
        this.creditHours = creditHours;
    }
    
    /**
     * Overloaded Constructor for initializing a course from an Array of Strings
     * @param record array of string that contains the attributes of a course
     */
    public Course(String[] record){
        this.code = record[0];
        this.title = record[1];
        this.level = Integer.parseInt(record[2]);
        this.creditHours = Integer.parseInt(record[3]);
        this.semesterOffered = Integer.parseInt(record[4]);
        this.type = record[5];
    }
    
    
    public void setPrereqs(String[] prereqs){
        this.prerequisites = prereqs;
    }
    
    public String[] getPrereqs(){
        return this.prerequisites;
    }
    
    public String getCode(){
        return this.code;
    }
    public boolean isCore(){
        return this.type.equals("core");
    }
    
    /**
     * Takes in an ArrayList of Courses and determines if those Courses cover the prerequisites for doing the current course.
     * @param completed
     * @return 
     */
    public boolean isQualified(ArrayList<Course> completed){
        String[] options;
        Course c;
        boolean optionFlag = false; 
        if (this.prerequisites == null) return true;
        for(String p : this.prerequisites){
             options = p.split(" OR ");
             for (String courseCode: options){
                 c = CourseCatalog.getCourseByCode(courseCode);
                 optionFlag = completed.contains(c);
                 if (optionFlag){
                     break;
                 }
             }
             if (!optionFlag) return false;
        }
        return true;
    }
    
    public int getCreditHours(){
        return this.creditHours;
    }
    
    public int getLevel(){
        return this.level;
    }
    
    @Override
    public String toString(){
        return this.code + ":" + this.title;
    }
    @Override
    public boolean equals(Object o){
        if (o instanceof Course){
            Course c = (Course) o;
            return this.getCode().equals(c.getCode());
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.code);
        return hash;
    }
}
