/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

/**
 *
 * @author njaco
 */
import java.util.ArrayList;
import java.util.Objects;

public class Course {
    private String code;
    private String title;
    private String type;
    private int semesterOffered;
    private int creditHours;
    private int level;
    private String[] prerequisites;
    
    
    public Course(String code, String title, int creditHours, int semesterOffered, String type){
        this.code = code;
        this.title = title;
        this.type = type;
        this.semesterOffered = semesterOffered;
        this.creditHours = creditHours;
    }
    
    public Course(String[] record){
        this.code = record[0];
        this.title = record[1];
        this.level = Integer.parseInt(record[2]);
        this.creditHours = Integer.parseInt(record[3]);
        this.semesterOffered = Integer.parseInt(record[4]);
        this.type = record[5];
    }
    
    
    public void setPrereqs(String[] prereqs){
        this.prerequisites = prereqs;
    }
    
    public String[] getPrereqs(){
        return this.prerequisites;
    }
    
    public String getCode(){
        return this.code;
    }
    public boolean isCore(){
        return this.type.equals("core");
    }
    
    public boolean isQualified(ArrayList<Course> completed){
        String[] options;
        Course c;
        boolean optionFlag = false; //For cases such as course1 OR course 2 etc., this allows us to check that at least 1 of the requirements are met.
        if (this.prerequisites == null) return true;
//        System.out.println("Prerequisites");
        for(String p : this.prerequisites){
             options = p.split(" OR ");
//              System.out.println(Arrays.toString(options));
             for (String courseCode: options){
                 c = CourseCatalog.getCourseByCode(courseCode);
                 optionFlag = completed.contains(c);
                 if (optionFlag){
//                     System.out.println("passed");
                     break;
                 }
             }
             if (!optionFlag) return false;
        }
        return true;
    }
    
    public int getCreditHours(){
        return this.creditHours;
    }
    
    public int getLevel(){
        return this.level;
    }
    
    @Override
    public String toString(){
        return this.code + ":" + this.title;
    }
    @Override
    public boolean equals(Object o){
        if (o instanceof Course){
            Course c = (Course) o;
            return this.getCode().equals(c.getCode());
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.code);
        return hash;
    }
}
