package comp3607.studentadvising;

import java.util.ArrayList;

/**
 * Extends the FileParser template and implements the variable steps necessary for parsing file containing a list of courses for the current semester
 * @author njaco
 */
public class CurrentSemesterParser extends FileParser{
    /**
     * Takes and String array record, which contains 1 element, a course code
     * Uses the static method of the CourseCatalog class to obtain a Course object which it adds to an ArrayList object that it then returns
     * @param o
     * @param record
     * @return 
     */
    @Override
    Object addEntry(Object o, String[] record) {
        ArrayList<Course> currentlyOfferedCourses = (ArrayList<Course>) o;
        currentlyOfferedCourses.add(CourseCatalog.getCourseByCode(record[0]));
        return currentlyOfferedCourses;
    }

    @Override
    Object getContainer() {
        return new ArrayList<Course>();
    }
    
}
