/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.util.ArrayList;

/**
 *
 * @author njaco
 */
public class CurrentSemesterParser extends FileParser{

    @Override
    Object addEntry(Object o, String[] record) {
        ArrayList<Course> currentlyOfferedCourses = (ArrayList<Course>) o;
        currentlyOfferedCourses.add(CourseCatalog.getCourseByCode(record[0]));
        return currentlyOfferedCourses;
    }

    @Override
    Object getContainer() {
        return new ArrayList<Course>();
    }
    
}
