        /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

/**
 *
 * @author njaco
 */

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
public class RecommenderSystem {
    private CourseCatalog cc;
    private Transcript ts;
    private CurrentSemesterParser csp;
    
    public RecommenderSystem(String transcriptPath){
        File file = new File("src/main/java/comp3607/studentadvising/courses.txt");
        String absolutePath = file.getAbsolutePath();
        cc = new CourseCatalog(absolutePath);
        csp = new CurrentSemesterParser();
        ts = new Transcript(transcriptPath);
    }
    
    public String getRecommendations(String currentSemester){
        String displayedRecommendations = "";
        String invalidInputMessage = "Transcript was badly formatted\nPlease upload a proper transcript";
        ArrayList<Course> offering = getOfferedCourses(currentSemester);
        if (ts == null) return invalidInputMessage;      
        int creditLimit = getCreditLimit(ts);
        if(creditLimit == -1) return invalidInputMessage;
        ArrayList<Course> recommendations = makeRecommendations(creditLimit, offering, ts);
        displayedRecommendations = recommendations.stream().map(c -> c.toString() + "\n").reduce(displayedRecommendations, String::concat);
        return displayedRecommendations;
    }
    
    private ArrayList<Course> getOfferedCourses(String currentSemester){
        String directoryPath = "src/main/java/comp3607/studentadvising/";
        String filename = currentSemester.equals("Semester 1") ? "S1.txt":"S2.txt";
        File file = new File(directoryPath + filename);
        String absolutePath = file.getAbsolutePath();
        return (ArrayList<Course>)csp.parse(absolutePath);
    }
    
    private int getCreditLimit(Transcript ts){
        if(ts.getGPA() == -1) return -1;
        if (ts.getGPA() <=2 ) return 9;
        if (ts.getFailedCourses().size() > 0) return 12;
        return 15;
    }
    
    private ArrayList<Course> makeRecommendations(int creditLimit, ArrayList<Course> coursesOffered, Transcript ts){
        ArrayList<Course> recommendations = new ArrayList<>();
        int currentCredits = 0;
        int electiveLimit = (creditLimit < 15)? 0:1;
        int currentElectives = 0;
        ArrayList<Course> completed = ts.getCompletedCourses();
        if (completed == null) return null;
        completed.removeAll(ts.getFailedCourses());

        ArrayList<Course> remainingCourses = new ArrayList<>(coursesOffered);
        remainingCourses.removeAll(completed);

        remainingCourses.addAll(ts.getFailedCourses());
        Iterator iter = remainingCourses.iterator();
        while ((currentCredits < creditLimit) && iter.hasNext()){
            Course c = (Course) iter.next();
            if (c.isQualified(completed)){
                if (c.isCore()){
                    recommendations.add(c);
                    currentCredits += c.getCreditHours();
                }
                else{
                    if(electiveLimit == 1 && currentElectives <1){
                        recommendations.add(c);
                        currentCredits += c.getCreditHours();
                    }
                }
            }
        }
        
        return recommendations;
    }
}
