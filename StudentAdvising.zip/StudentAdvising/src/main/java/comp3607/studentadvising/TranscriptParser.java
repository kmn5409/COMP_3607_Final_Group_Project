/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.util.HashMap;

/**
 *
 * @author njaco
 */
public class TranscriptParser extends FileParser {

    @Override
    Object addEntry(Object o, String[] record) {
        if(o == null) return null;
        HashMap<Course, String> completedCourses = (HashMap<Course, String>) o;
        try{
            completedCourses.put(CourseCatalog.getCourseByCode(record[0]), record[1]);
        }
        catch (Exception e){
            return null;
        }
        
        return completedCourses;
    }

    @Override
    Object getContainer() {
        return new HashMap<Course, String>();
    }
    
}
