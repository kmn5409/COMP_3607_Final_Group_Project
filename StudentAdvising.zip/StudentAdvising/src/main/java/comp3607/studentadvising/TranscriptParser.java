package comp3607.studentadvising;

import java.util.HashMap;

/**
 *TranscriptParser extends the FileParse template and implements the variable steps
 * 
 * @author njaco
 */
public class TranscriptParser extends FileParser {
    /**
     * Takes in a record, which is supposed to be a course code - grade pair
     * The CourseCatalog class is used to create a Course object from the course code String
     * The Course object, and the grade are put in a HashMap which is then returned
     * @param o
     * @param record
     * @return 
     */
    @Override
    Object addEntry(Object o, String[] record) {
        if(o == null) return null;
        HashMap<Course, String> completedCourses = (HashMap<Course, String>) o;
        try{
            completedCourses.put(CourseCatalog.getCourseByCode(record[0]), record[1]);
        }
        catch (Exception e){
            return null;
        }
        
        return completedCourses;
    }

    @Override
    Object getContainer() {
        return new HashMap<Course, String>();
    }
    
}
