package comp3607.studentadvising;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * CatalogParser extends File parser template to implement variable steps to the 
 * information about all courses in our scope
 * @author njaco
 */
public class CatalogParser extends FileParser {

    /**
     * takes a record (line) read from the course list file, parses it to a Course object and adds it to an ArrayList of Courses, which it then returns
     * Return type is Object to keep it as generic as possible to allow using other containers
     * @param o Object
     * @param record String []
     * @return completed courses
     */
    @Override
    Object addEntry(Object o, String[] record) {
        ArrayList<Course> courses = (ArrayList<Course>) o;
        Course c  = new Course(Arrays.copyOfRange(record, 0,6));
        if (record.length == 6) c.setPrereqs(null);
        else c.setPrereqs(Arrays.copyOfRange(record, 6, record.length));
        courses.add(c);
        return courses;   
    }
    
    @Override
    Object getContainer() {
        return new ArrayList<Course>(); 
    }
    
}
