/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author njaco
 */
public class CatalogParser extends FileParser {

    @Override
    Object addEntry(Object o, String[] record) {
        ArrayList<Course> courses = (ArrayList<Course>) o;
        Course c  = new Course(Arrays.copyOfRange(record, 0,6));
        if (record.length == 6) c.setPrereqs(null);
        else c.setPrereqs(Arrays.copyOfRange(record, 6, record.length));
        courses.add(c);
        return courses;   
    }

    @Override
    Object getContainer() {
        return new ArrayList<Course>(); 
    }
    
}
