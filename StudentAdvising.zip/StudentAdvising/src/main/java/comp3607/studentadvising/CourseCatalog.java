/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

/**
 *
 * @author njaco
 */

import java.util.ArrayList;


public class CourseCatalog {
    private static ArrayList<Course> courses;
    private CatalogParser cp;
    
    public CourseCatalog(String filePath){
        cp = new CatalogParser();
        courses = (ArrayList<Course>) cp.parse(filePath);
    }
    
    public static Course getCourseByCode(String code){
        for (Course c: courses){
            if (c.getCode().equals(code)){
                return c;
            }
        }
        return null;
    }
}
