package comp3607.studentadvising;

/**
 *
 * @author njaco
 */

import java.util.ArrayList;


/**
 * Contains a static list of all courses in our scope 
 * 
 */
public class CourseCatalog {
    private static ArrayList<Course> courses;
    private CatalogParser cp;
    
    /**
     * Constructor creates a new CatalogParser instance and populated an ArrayList of Courses.
     * @param filePath name of the course file
     */
    public CourseCatalog(String filePath){
        cp = new CatalogParser();
        courses = (ArrayList<Course>) cp.parse(filePath);
    }
    
    /**
     * a static method that is used to obtain Course objects from course code String
     * @param code course code String
     * @return Course 
     */
    public static Course getCourseByCode(String code){
        for (Course c: courses){
            if (c.getCode().equals(code)){
                return c;
            }
        }
        return null;
    }
}
