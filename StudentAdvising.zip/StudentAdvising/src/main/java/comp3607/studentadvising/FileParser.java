/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author njaco
 */
public abstract class FileParser {
    Object parse(String filePath){
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            
            String[] record;
            
            String line = br.readLine();
            Object container = getContainer();
            
            while (line != null){
                record = line.split(",");
                
                container = addEntry(container, record);
                line = br.readLine();
            }
            br.close();
//            System.out.println(container);
            return container;
        }
        catch (Exception e){
            System.out.println("Exception " + e.getMessage());
            return null;
        }
    }
    
    abstract Object addEntry(Object o, String [] record);
    
    abstract Object getContainer();
}
