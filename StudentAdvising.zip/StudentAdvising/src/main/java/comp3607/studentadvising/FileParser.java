package comp3607.studentadvising;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author njaco
 */
public abstract class FileParser {
     /**
     * Template method that opens a file and calls other functions (variable steps) to parse the lines of the file to an object and load a container for storing parsed objects
     * @param filePath the name of the file
     * @return object container 
     */
    Object parse(String filePath){
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            
            String[] record;
            
            String line = br.readLine();
            Object container = getContainer();
            
            while (line != null){
                record = line.split(",");
                
                container = addEntry(container, record);
                line = br.readLine();
            }
            br.close();
//            System.out.println(container);
            return container;
        }
        catch (Exception e){
            System.out.println("Exception " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Parses the record contained in the String Array and adds it to the Object that is passed in
     * @param o 
     * @param record
     * @return 
     */
    abstract Object addEntry(Object o, String [] record);
    
    /**
     * Returns an appropriate object depending on the Class that extends the Template 
     * @return Object
     */
    abstract Object getContainer();
}
