/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

/**
 *
 * @author njaco
 */

import java.util.ArrayList;

public class Student {
    private Transcript ts;
    
    public double getGPA(){
        return ts.getGPA();
    }
    
    public ArrayList<Course> getFailedCourses(){
        return ts.getFailedCourses();
    }
}
