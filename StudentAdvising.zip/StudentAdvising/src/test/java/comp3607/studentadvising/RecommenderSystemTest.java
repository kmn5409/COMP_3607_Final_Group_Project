/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;

/**
 *
 * @author njaco
 */
public class RecommenderSystemTest {
    
    private RecommenderSystem recommenderSystem1;
    private RecommenderSystem recommenderSystem2;
    
    
    public RecommenderSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        System.out.println("Executing before all...");
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        System.out.println("Executing before each...");
        File file1 = new File("src/test/java/comp3607/studentadvising/testTranscript1.txt");
        File file2 = new File("src/test/java/comp3607/studentadvising/badTestTranscript.txt");
        recommenderSystem1 = new RecommenderSystem(file1.getAbsolutePath());
        recommenderSystem2 = new RecommenderSystem(file2.getAbsolutePath());
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getRecommendations method, of class RecommenderSystem.
     */
    @Test
    public void testGetRecommendations() {
        System.out.println("getRecommendations");
        
        String actual = recommenderSystem1.getRecommendations("Semester 1");
        String expected = getExpectedRecommendations();
        assertEquals(expected.trim(), actual.trim());
        
        String expResult = "Transcript was badly formatted\nPlease upload a proper transcript";
        String result = recommenderSystem2.getRecommendations("Semester 2");
        
        assertEquals(expResult, result);
        
    }
    
    public String getExpectedRecommendations(){
        return "COMP 1600:Introduction to Computing Concepts\n"+
        "COMP 1601:Computer Programming I\n"+
        "ACCT 1002:Introduction to Financial Accounting\n"+
        "MGMT 2021:Business Law\n";
    }
    
}
