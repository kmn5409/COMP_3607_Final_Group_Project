/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.io.File;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author njaco
 */
public class CurrentSemesterParserTest {
    private CurrentSemesterParser csp;
    
    public CurrentSemesterParserTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        System.out.println("Executing before each...");
        csp = new CurrentSemesterParser();
        System.out.println("Executing before each...");
        File file = new File("src/test/java/comp3607/studentadvising/testTranscript1.txt");
        String absolutePath = file.getAbsolutePath();
        RecommenderSystem recommenderSystem = new RecommenderSystem(absolutePath);
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addEntry method, of class CurrentSemesterParser.
     */
    
    @Test
    public void testParse(){
        File file = new File("src/main/java/comp3607/studentadvising/S2.txt");
        String absolutePath = file.getAbsolutePath();
        ArrayList<Course> coursesList = (ArrayList<Course>)csp.parse(absolutePath);
        String actual = getCourseNames(coursesList);
        String expected = semesterTwo();
        assertEquals(expected, actual);
    }
    
    public String getCourseNames(ArrayList<Course> actual){
        String courses = "";
        courses = actual.stream().map(c -> c.toString()).reduce(courses, String::concat);
        return courses;
    }
    
    public String semesterTwo(){
        return "COMP 1602:Computer Programming II"+
        "COMP 1603:Computer Programming III"+
        "COMP 2603:Object-Oriented Programming I"+
        "COMP 2604:Operating Systems"+
        "ACCT 1003:Introduction to Cost and Managerial Accounting"+
        "ECON 1002:Introduction to Macroeconomics"+
        "MGMT 2008:Organisational Behaviour"+
        "MGMT 2032:Managerial Economics"+
        "MKTG 2001:Principles of Marketing";
    }
}
