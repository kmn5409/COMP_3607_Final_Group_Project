/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3607.studentadvising;

import java.util.ArrayList;
import java.io.File;
import java.util.HashSet;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



/**
 *
 * @author njaco
 */
public class TranscriptTest {
    private Transcript transcript;

    
    public TranscriptTest() {
    }
    
    @BeforeAll
    public static void setUpClass() { 
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        System.out.println("Executing before each...");
        File file = new File("src/test/java/comp3607/studentadvising/testTranscript2.txt");
        String absolutePath = file.getAbsolutePath();
        RecommenderSystem recommenderSystem = new RecommenderSystem(absolutePath);
        transcript = new Transcript(absolutePath);
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getGPA method, of class Transcript.
     */
    @Test
    public void testGetGPA() {
        System.out.println("getGPA");
        double expResult = 3.04;
        double result = transcript.getGPA();
        assertEquals(expResult, result, 0.01);
    }

    /**
     * Test of getFailedCourses method, of class Transcript.
     */
    @Test
    public void testGetFailedCourses() {
        System.out.println("getFailedCourses");
        String expString = "COMP 1600,"+ "ECON 1002";
        ArrayList<Course> expResult = getArrayListFromString(expString.split(","));
        ArrayList<Course> result = transcript.getFailedCourses();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCompletedCourses method, of class Transcript.
     */
    @Test
    public void testGetCompletedCourses() {
        System.out.println("getCompletedCourses");
        String expString = "ACCT 1002," +
            "COMP 1600," +
            "COMP 1601," +
            "ECON 1001," +
            "ACCT 1003," +
            "COMP 1602," +
            "COMP 1603," +
            "ECON 1002,";
        ArrayList<Course> expResult = getArrayListFromString(expString.split(","));
        ArrayList<Course> result = transcript.getCompletedCourses();
        assertEquals(expResult, result);
    }
    
    /**
     * 
     * @param str
     * @return  an ArrayList of Courses
     * 
     * A HashSet is used here to endure that list is sorted in same order as it would be in Class
     * 
     */
    private ArrayList<Course> getArrayListFromString(String [] str){
        HashSet<Course> returnArray = new HashSet<>();
        for (String s: str){
            returnArray.add(CourseCatalog.getCourseByCode(s));
        }
        return new ArrayList<>(returnArray);
    }
    
}
